import assert from "node:assert/strict";
import test from "node:test";

import plugin from "../index.js";
import { SAFE_MESSAGE, createAnhDuongCoreHooks } from "../src/hooks.js";

const ENV = {
  ANH_DUONG_CORE_ENABLED: "true",
  ANH_DUONG_CORE_BASE_URL: "http://core.local:8790",
  ANH_DUONG_CORE_INTERNAL_TOKEN: "hook-test-token",
  ANH_DUONG_CORE_TIMEOUT_SECONDS: "1",
};

function responseFixture(requestId) {
  return {
    request_id: requestId,
    normalized_text: "hello",
    persona: { version: "1", content_hash: "b".repeat(64) },
    route_decision: { route: "direct", rule_id: "route-direct", reason: "fixture" },
    capability_decision: {
      capability: "conversational_response",
      source_route: "direct",
      reason_code: "direct",
      matched_signals: [],
    },
    context: {
      sections: [],
      rendered_context: "prepared context",
      token_budget: {},
      estimated_tokens: 2,
      remaining_tokens: 100,
      dropped_items: [],
      truncated_items: [],
      warnings: [],
      provenance: [],
    },
    project_id: null,
    task_id: null,
    execution_required: false,
    warnings: [],
    provenance: {
      persona_version: "1",
      persona_content_hash: "b".repeat(64),
      route_rule_id: "route-direct",
      capability_reason_code: "direct",
      project_version: null,
      task_version: null,
      context_source_refs: [],
    },
    created_at: "2026-08-01T04:00:00Z",
  };
}

function telegramContext(runId = "run-1") {
  return {
    runId,
    messageProvider: "telegram",
    channel: "telegram",
    senderId: "private-sender",
    chatId: "private-chat",
    sessionKey: "private-session",
  };
}

function collectingLogger() {
  const entries = [];
  return {
    entries,
    info(message) {
      entries.push(String(message));
    },
    warn(message) {
      entries.push(String(message));
    },
  };
}

test("disabled integration and non-Telegram turns bypass Core and model gating", async () => {
  let calls = 0;
  const fetchImpl = async () => {
    calls += 1;
    throw new Error("must not run");
  };
  const disabled = createAnhDuongCoreHooks({
    env: { ANH_DUONG_CORE_ENABLED: "false" },
    fetchImpl,
  });
  assert.equal(await disabled.beforePromptBuild({ prompt: "hello", messages: [] }, telegramContext()), undefined);
  assert.equal(await disabled.beforeAgentRun({ prompt: "hello", messages: [] }, telegramContext()), undefined);

  const enabled = createAnhDuongCoreHooks({ env: ENV, fetchImpl });
  const discord = { runId: "run-discord", messageProvider: "discord", channel: "discord" };
  assert.equal(await enabled.beforePromptBuild({ prompt: "hello", messages: [] }, discord), undefined);
  assert.equal(await enabled.beforeAgentRun({ prompt: "hello", messages: [] }, discord), undefined);
  assert.equal(calls, 0);
});

test("successful Telegram preparation injects context then allows model execution", async () => {
  let calls = 0;
  const fetchImpl = async (_url, init) => {
    calls += 1;
    const body = JSON.parse(init.body);
    return new Response(JSON.stringify(responseFixture(body.request_id)), { status: 200 });
  };
  const hooks = createAnhDuongCoreHooks({ env: ENV, fetchImpl });
  const ctx = telegramContext("run-success");

  const injection = await hooks.beforePromptBuild({ prompt: "hello", messages: [] }, ctx);
  const gate = await hooks.beforeAgentRun({ prompt: "hello", messages: [] }, ctx);

  assert.equal(calls, 1);
  assert.match(injection.prependContext, /request_id: tg-run-success/);
  assert.deepEqual(gate, { outcome: "pass" });
});

test("pending preparation blocks before model input", async () => {
  let release;
  const fetchImpl = async (_url, init) => {
    await new Promise((resolve) => {
      release = resolve;
    });
    const body = JSON.parse(init.body);
    return new Response(JSON.stringify(responseFixture(body.request_id)), { status: 200 });
  };
  const hooks = createAnhDuongCoreHooks({ env: ENV, fetchImpl });
  const ctx = telegramContext("run-pending");
  const pending = hooks.beforePromptBuild({ prompt: "hello", messages: [] }, ctx);
  await new Promise((resolve) => setImmediate(resolve));

  assert.deepEqual(await hooks.beforeAgentRun({ prompt: "hello", messages: [] }, ctx), {
    outcome: "block",
    reason: "anh_duong_core_unavailable",
    category: "core_unavailable",
    message: SAFE_MESSAGE,
  });

  release();
  await pending;
});

for (const [name, fetchImpl] of [
  ["connection failure", async () => { throw new TypeError("ECONNREFUSED hook-test-token private-chat"); }],
  ["authentication failure", async () => new Response("private body", { status: 401 })],
  ["invalid response", async () => new Response("{}", { status: 200 })],
]) {
  test(`${name} blocks the model and emits only sanitized logs`, async () => {
    const logger = collectingLogger();
    const hooks = createAnhDuongCoreHooks({ env: ENV, fetchImpl, logger });
    const ctx = telegramContext(`run-${name.replaceAll(" ", "-")}`);

    assert.equal(await hooks.beforePromptBuild({ prompt: "private prompt", messages: [] }, ctx), undefined);
    assert.deepEqual(await hooks.beforeAgentRun({ prompt: "private prompt", messages: [] }, ctx), {
      outcome: "block",
      reason: "anh_duong_core_unavailable",
      category: "core_unavailable",
      message: SAFE_MESSAGE,
    });

    const logs = logger.entries.join("\n");
    for (const forbidden of ["hook-test-token", "private-chat", "private-sender", "private-session", "private prompt", "private body", "Authorization"]) {
      assert.equal(logs.includes(forbidden), false);
    }
  });
}

test("missing run ID fails closed for an enabled Telegram turn", async () => {
  const hooks = createAnhDuongCoreHooks({ env: ENV, fetchImpl: async () => { throw new Error("must not run"); } });
  const ctx = telegramContext(undefined);
  delete ctx.runId;
  assert.equal(await hooks.beforePromptBuild({ prompt: "hello", messages: [] }, ctx), undefined);
  assert.equal((await hooks.beforeAgentRun({ prompt: "hello", messages: [] }, ctx)).outcome, "block");
});

test("agent-end cleanup removes prepared state", async () => {
  const fetchImpl = async (_url, init) => {
    const body = JSON.parse(init.body);
    return new Response(JSON.stringify(responseFixture(body.request_id)), { status: 200 });
  };
  const hooks = createAnhDuongCoreHooks({ env: ENV, fetchImpl });
  const ctx = telegramContext("run-cleanup");
  await hooks.beforePromptBuild({ prompt: "hello", messages: [] }, ctx);
  assert.equal((await hooks.beforeAgentRun({ prompt: "hello", messages: [] }, ctx)).outcome, "pass");
  await hooks.agentEnd({}, ctx);
  assert.equal((await hooks.beforeAgentRun({ prompt: "hello", messages: [] }, ctx)).outcome, "block");
});

test("plugin entry registers exactly the three TG-1 hooks with finite timeouts", () => {
  const registrations = [];
  plugin.register({
    logger: collectingLogger(),
    on(name, handler, options) {
      registrations.push({ name, handler, options });
    },
  });
  assert.deepEqual(
    registrations.map(({ name }) => name),
    ["before_prompt_build", "before_agent_run", "agent_end"],
  );
  assert.ok(registrations[0].options.timeoutMs > 0);
  assert.ok(registrations[1].options.timeoutMs > 0);
});
