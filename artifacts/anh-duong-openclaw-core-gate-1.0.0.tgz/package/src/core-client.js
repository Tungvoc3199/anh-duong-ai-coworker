import { createHash } from "node:crypto";

import { CoreIntegrationError } from "./config.js";

const ROUTES = new Set(["direct", "memory", "core_read", "workflow"]);
const CAPABILITIES = new Set([
  "conversational_response",
  "memory_search",
  "project_read",
  "task_read",
  "core_status_read",
  "planning",
  "file_operation",
  "code_operation",
  "external_communication",
  "system_operation",
  "unknown_workflow",
]);

function sha256(value) {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function validationError(requestId) {
  return new CoreIntegrationError("validation", { requestId });
}

function requireObject(value, requestId) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw validationError(requestId);
  }
  return value;
}

function requireString(value, requestId, { maxLength } = {}) {
  if (typeof value !== "string" || value.length === 0 || (maxLength && value.length > maxLength)) {
    throw validationError(requestId);
  }
  return value;
}

function requireStringArray(value, requestId) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw validationError(requestId);
  }
  return value;
}

export function buildCoreRequest({ prompt, runId, senderId }) {
  if (typeof prompt !== "string" || prompt.trim().length === 0 || prompt.length > 20_000) {
    throw validationError();
  }
  if (typeof runId !== "string" || runId.trim().length === 0) {
    throw validationError();
  }

  const directRequestId = `tg-${runId}`;
  const requestId = directRequestId.length <= 128 ? directRequestId : `tg-${sha256(runId)}`;
  const actor =
    typeof senderId === "string" && senderId.length > 0
      ? `telegram:${sha256(senderId)}`
      : "telegram:anonymous";

  return {
    text: prompt,
    request_id: requestId,
    channel: "telegram",
    actor,
  };
}

export function validatePreparedRequest(value, expectedRequestId) {
  const root = requireObject(value, expectedRequestId);
  const requestId = requireString(root.request_id, expectedRequestId, { maxLength: 128 });
  if (requestId !== expectedRequestId) {
    throw validationError(expectedRequestId);
  }
  requireString(root.normalized_text, expectedRequestId, { maxLength: 20_000 });

  const persona = requireObject(root.persona, expectedRequestId);
  requireString(persona.version, expectedRequestId);
  if (!/^[0-9a-f]{64}$/.test(requireString(persona.content_hash, expectedRequestId))) {
    throw validationError(expectedRequestId);
  }

  const routeDecision = requireObject(root.route_decision, expectedRequestId);
  const route = requireString(routeDecision.route, expectedRequestId);
  if (!ROUTES.has(route)) {
    throw validationError(expectedRequestId);
  }
  requireString(routeDecision.rule_id, expectedRequestId);
  requireString(routeDecision.reason, expectedRequestId);

  const capabilityDecision = requireObject(root.capability_decision, expectedRequestId);
  const capability = requireString(capabilityDecision.capability, expectedRequestId);
  if (!CAPABILITIES.has(capability)) {
    throw validationError(expectedRequestId);
  }
  if (capabilityDecision.source_route !== route) {
    throw validationError(expectedRequestId);
  }
  requireString(capabilityDecision.reason_code, expectedRequestId);
  requireStringArray(capabilityDecision.matched_signals, expectedRequestId);

  const context = requireObject(root.context, expectedRequestId);
  requireString(context.rendered_context, expectedRequestId);
  if (typeof root.execution_required !== "boolean") {
    throw validationError(expectedRequestId);
  }
  if ((route === "workflow") !== root.execution_required) {
    throw validationError(expectedRequestId);
  }
  requireStringArray(root.warnings, expectedRequestId);

  const provenance = requireObject(root.provenance, expectedRequestId);
  requireString(provenance.persona_version, expectedRequestId);
  if (!/^[0-9a-f]{64}$/.test(requireString(provenance.persona_content_hash, expectedRequestId))) {
    throw validationError(expectedRequestId);
  }
  requireString(provenance.route_rule_id, expectedRequestId);
  requireString(provenance.capability_reason_code, expectedRequestId);
  requireStringArray(provenance.context_source_refs, expectedRequestId);

  const createdAt = requireString(root.created_at, expectedRequestId);
  if (!/(?:Z|[+-]\d{2}:\d{2})$/.test(createdAt) || Number.isNaN(Date.parse(createdAt))) {
    throw validationError(expectedRequestId);
  }

  return root;
}

export async function prepareCoreRequest({ config, request, fetchImpl = fetch }) {
  const requestId = request?.request_id;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.timeoutMs);

  try {
    let response;
    try {
      response = await fetchImpl(`${config.baseUrl}/api/internal/requests/prepare`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.token}`,
        },
        body: JSON.stringify(request),
        signal: controller.signal,
      });
    } catch {
      if (controller.signal.aborted) {
        throw new CoreIntegrationError("timeout", { requestId });
      }
      throw new CoreIntegrationError("connection", { requestId });
    }

    if (!response || typeof response.status !== "number" || typeof response.json !== "function") {
      throw validationError(requestId);
    }
    if (!response.ok) {
      const failureClass = response.status === 401 || response.status === 403 ? "authentication" : "http";
      throw new CoreIntegrationError(failureClass, { status: response.status, requestId });
    }

    let value;
    try {
      value = await response.json();
    } catch {
      throw validationError(requestId);
    }
    return validatePreparedRequest(value, requestId);
  } finally {
    clearTimeout(timer);
  }
}
