from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import pytest

from app.audit import AuditEvent
from app.capabilities import CapabilityKind, CapabilityRouter
from app.context_builder import ContextBuilder, ContextSectionKind
from app.memory import (
    HybridMemorySearchResult,
    Memory,
    MemoryRepositoryError,
    MemoryType,
)
from app.orchestration import (
    CoreRequest,
    CoreRequestPipeline,
    PersonaReference,
    ProjectContextNotFound,
    TaskContextNotFound,
    TaskProjectMismatch,
)
from app.persona import PersonaSnapshot
from app.projects import (
    Project,
    ProjectNotFound,
    ProjectPriority,
    ProjectStatus,
)
from app.routing import FastRoute, FastRouter
from app.tasks import Task, TaskNotFound, TaskPriority, TaskStatus

NOW = datetime(2026, 8, 1, 3, 0, tzinfo=UTC)


class RecordingRetriever:
    def __init__(self, results: list[HybridMemorySearchResult] | None = None) -> None:
        self.results = results or []
        self.calls: list[tuple[str, dict[str, Any]]] = []

    def retrieve(
        self,
        query: str,
        **kwargs: Any,
    ) -> list[HybridMemorySearchResult]:
        self.calls.append((query, kwargs))
        return list(self.results)


class FailingRetriever:
    def retrieve(
        self,
        query: str,
        **kwargs: Any,
    ) -> list[HybridMemorySearchResult]:
        raise MemoryRepositoryError("memory unavailable")


class ProjectReader:
    def __init__(self, projects: tuple[Project, ...] = ()) -> None:
        self.projects = {project.id: project for project in projects}

    def get(self, project_id: str) -> Project:
        try:
            return self.projects[project_id]
        except KeyError as error:
            raise ProjectNotFound(f"Project not found: {project_id}") from error


class TaskReader:
    def __init__(self, tasks: tuple[Task, ...] = ()) -> None:
        self.tasks = {task.id: task for task in tasks}

    def get(self, task_id: str) -> Task:
        try:
            return self.tasks[task_id]
        except KeyError as error:
            raise TaskNotFound(f"Task not found: {task_id}") from error


class RecordingAuditWriter:
    def __init__(self) -> None:
        self.events: list[AuditEvent] = []

    def write(self, event: AuditEvent) -> None:
        self.events.append(event)


def _persona() -> PersonaSnapshot:
    return PersonaSnapshot(
        version="1.7",
        content_hash="b" * 64,
        file_order=("IDENTITY.md",),
        files={"IDENTITY.md": "Ánh Dương — AI coworker an toàn."},
        combined_content="Ánh Dương — AI coworker an toàn.",
    )


def _project(project_id: str = "proj_or1") -> Project:
    return Project(
        id=project_id,
        name="Ánh Dương Core",
        slug="anh-duong-core",
        status=ProjectStatus.ACTIVE,
        priority=ProjectPriority.HIGH,
        path_windows=r"F:\AIOS\anh-duong-core",
        path_wsl="/mnt/f/AIOS/anh-duong-core",
        repo_url=None,
        current_phase="OR-1",
        owner="user",
        summary="Build the AI coworker request pipeline.",
        next_action="Run OR-1 tests.",
        constraints=("No schema changes",),
        created_at=NOW,
        updated_at=NOW,
        last_activity_at=NOW,
        version=4,
    )


def _task(
    task_id: str = "task_or1",
    *,
    project_id: str = "proj_or1",
) -> Task:
    return Task(
        id=task_id,
        project_id=project_id,
        title="Build Core Request Pipeline v1",
        description="Prepare requests without executing capabilities.",
        status=TaskStatus.PLANNING,
        priority=TaskPriority.HIGH,
        risk_level=0,
        requested_by="user",
        source_channel="internal",
        approval_required=False,
        current_step_id=None,
        result_summary=None,
        deadline=None,
        created_at=NOW,
        updated_at=NOW,
        version=3,
    )


def _memory() -> HybridMemorySearchResult:
    memory = Memory(
        id="mem_or1",
        memory_type=MemoryType.PROJECT,
        scope_id="scope_or1",
        title="OR-1 constraint",
        content="OR-1 must never execute a capability.",
        summary=None,
        importance=0.9,
        confidence=1.0,
        source="unit-test",
        expires_at=None,
        tags=("or-1",),
        created_at=NOW,
        updated_at=NOW,
        version=1,
    )
    return HybridMemorySearchResult(
        memory=memory,
        fts_rank=-1.0,
        lexical_score=1.0,
        importance_score=0.9,
        confidence_score=1.0,
        recency_score=1.0,
        hybrid_score=0.96,
    )


def _pipeline(
    *,
    retriever: RecordingRetriever | FailingRetriever | None = None,
    project_reader: ProjectReader | None = None,
    task_reader: TaskReader | None = None,
    audit_writer: RecordingAuditWriter | None = None,
) -> CoreRequestPipeline:
    return CoreRequestPipeline(
        persona_loader=_persona,
        fast_router=FastRouter(),
        capability_router=CapabilityRouter(),
        context_builder=ContextBuilder(retriever or RecordingRetriever()),
        project_reader=project_reader or ProjectReader(),
        task_reader=task_reader or TaskReader(),
        audit_writer=audit_writer or RecordingAuditWriter(),
        clock=lambda: NOW,
        id_factory=lambda: "req_fixed",
    )


def test_direct_request_produces_complete_prepared_request() -> None:
    prepared = _pipeline().prepare(
        CoreRequest(text="  Xin   chào!  ", request_id="client-request-1")
    )

    assert prepared.request_id == "client-request-1"
    assert prepared.normalized_text == "Xin chào!"
    assert prepared.persona == PersonaReference(
        version="1.7",
        content_hash="b" * 64,
    )
    assert prepared.route_decision.route is FastRoute.DIRECT
    assert (
        prepared.capability_decision.capability
        is CapabilityKind.CONVERSATIONAL_RESPONSE
    )
    assert prepared.execution_required is False
    assert prepared.created_at == NOW

def test_tg1_simple_arithmetic_request_routes_direct() -> None:
    prepared = _pipeline().prepare(
        CoreRequest(
            text=(
                "TG1-DIRECT-20260801 — Tính 27 + 15 và trả lời ngắn gọn."
            ),
            request_id="tg1-direct-regression",
        )
    )

    assert prepared.route_decision.route is FastRoute.DIRECT
    assert (
        prepared.capability_decision.capability
        is CapabilityKind.CONVERSATIONAL_RESPONSE
    )
    assert prepared.execution_required is False


def test_memory_request_uses_context_builder_and_scope() -> None:
    retriever = RecordingRetriever([_memory()])

    prepared = _pipeline(retriever=retriever).prepare(
        CoreRequest(
            text="Bạn có nhớ tôi đã nói gì về OR-1 không?",
            memory_scope_id="scope_or1",
        )
    )

    assert prepared.route_decision.route is FastRoute.MEMORY
    assert prepared.capability_decision.capability is CapabilityKind.MEMORY_SEARCH
    assert "OR-1 must never execute a capability." in prepared.context.rendered_context
    assert len(retriever.calls) == 1
    assert retriever.calls[0][1] == {"scope_id": "scope_or1", "limit": 20}


def test_project_request_reads_and_renders_registry_snapshot() -> None:
    project = _project()

    prepared = _pipeline(
        project_reader=ProjectReader((project,)),
    ).prepare(
        CoreRequest(
            text="Tiến độ Project Ánh Dương thế nào?",
            project_id=project.id,
        )
    )

    assert prepared.route_decision.route is FastRoute.CORE_READ
    assert prepared.capability_decision.capability is CapabilityKind.PROJECT_READ
    assert prepared.project_id == project.id
    assert "identity: proj_or1" in prepared.context.rendered_context
    assert "current_phase: OR-1" in prepared.context.rendered_context
    assert prepared.provenance.project_version == 4


def test_task_request_reads_and_renders_registry_snapshot() -> None:
    task = _task()

    prepared = _pipeline(task_reader=TaskReader((task,))).prepare(
        CoreRequest(
            text="Task OR-1 đang ở trạng thái nào?",
            task_id=task.id,
        )
    )

    assert prepared.capability_decision.capability is CapabilityKind.TASK_READ
    assert prepared.task_id == task.id
    assert "identity: task_or1" in prepared.context.rendered_context
    assert "Build Core Request Pipeline v1" in prepared.context.rendered_context
    assert prepared.provenance.task_version == 3


def test_workflow_and_ambiguous_requests_require_later_execution_only() -> None:
    workflow = _pipeline().prepare(CoreRequest(text="Chạy pytest cho app."))
    unknown = _pipeline().prepare(CoreRequest(text="Màu tím."))

    assert workflow.route_decision.route is FastRoute.WORKFLOW
    assert workflow.capability_decision.capability is CapabilityKind.CODE_OPERATION
    assert workflow.execution_required is True
    assert unknown.route_decision.route is FastRoute.WORKFLOW
    assert unknown.capability_decision.capability is CapabilityKind.UNKNOWN_WORKFLOW
    assert unknown.execution_required is True


def test_missing_project_and_task_raise_clear_pipeline_errors() -> None:
    pipeline = _pipeline()

    with pytest.raises(ProjectContextNotFound, match="proj_missing"):
        pipeline.prepare(
            CoreRequest(text="Xem Project missing.", project_id="proj_missing")
        )
    with pytest.raises(TaskContextNotFound, match="task_missing"):
        pipeline.prepare(
            CoreRequest(text="Xem Task missing.", task_id="task_missing")
        )


def test_explicit_task_project_mismatch_is_rejected() -> None:
    project = _project("proj_requested")
    task = _task(project_id="proj_actual")

    with pytest.raises(TaskProjectMismatch, match="proj_actual"):
        _pipeline(
            project_reader=ProjectReader((project,)),
            task_reader=TaskReader((task,)),
        ).prepare(
            CoreRequest(
                text="Xem trạng thái Task OR-1.",
                project_id=project.id,
                task_id=task.id,
            )
        )


def test_fixed_clock_and_id_make_output_deterministic() -> None:
    pipeline = _pipeline()
    request = CoreRequest(text="Xin chào!")

    assert pipeline.prepare(request) == pipeline.prepare(request)


def test_context_warning_budget_decisions_and_provenance_are_propagated() -> None:
    prepared = _pipeline(retriever=FailingRetriever()).prepare(
        CoreRequest(text="Xin chào!")
    )

    assert prepared.warnings == (
        "memory_retrieval_failed: MemoryRepositoryError",
    )
    assert prepared.warnings == prepared.context.warnings
    assert prepared.context.estimated_tokens <= (
        prepared.context.token_budget.usable_context_tokens
    )
    assert prepared.provenance.route_rule_id == prepared.route_decision.rule_id
    assert (
        prepared.provenance.capability_reason_code
        == prepared.capability_decision.reason_code
    )
    assert "request:current" in prepared.provenance.context_source_refs


def test_secret_is_redacted_from_all_prepared_response_text() -> None:
    secret = "sk-proj-abcdefghijklmnopqrstuvwxyz"

    prepared = _pipeline().prepare(
        CoreRequest(text=f"Ghi nhớ api_key={secret}")
    )

    serialized = str(prepared.model_dump(mode="json"))
    assert secret not in serialized
    assert "api_key=[REDACTED]" in prepared.normalized_text


def test_success_writes_one_minimal_audit_event() -> None:
    writer = RecordingAuditWriter()

    prepared = _pipeline(audit_writer=writer).prepare(
        CoreRequest(
            text="Xin chào! api_key=sk-proj-abcdefghijklmnopqrstuvwxyz",
            actor="desktop",
            channel="internal",
        )
    )

    assert len(writer.events) == 1
    event = writer.events[0]
    assert event.event_type == "request.prepared"
    assert event.actor == "desktop"
    assert event.request_id == prepared.request_id
    assert event.payload == {
        "request_id": "req_fixed",
        "channel": "internal",
        "project_id": None,
        "task_id": None,
        "route": "workflow",
        "capability": "unknown_workflow",
        "persona_version": "1.7",
        "persona_content_hash": "b" * 64,
        "token_estimate": prepared.context.estimated_tokens,
        "warning_count": 0,
    }
    assert "sk-proj" not in str(event.model_dump(mode="json"))


def test_context_bundle_preserves_required_section_order() -> None:
    prepared = _pipeline().prepare(CoreRequest(text="Xin chào!"))

    assert tuple(section.kind for section in prepared.context.sections) == tuple(
        ContextSectionKind
    )
